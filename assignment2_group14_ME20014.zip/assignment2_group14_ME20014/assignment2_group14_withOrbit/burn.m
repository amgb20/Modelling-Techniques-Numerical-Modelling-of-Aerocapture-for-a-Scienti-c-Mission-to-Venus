function [Fb] = burn(z)
%Function computing the value for the burn force.

theta = calcTheta(z);                   % calculate the angle between position and planet
[T,unitvecT,magT] = calcT(z,theta);     % calculate the Tangental velocity, it's unit vector and vector magitude
P = calcP(z,theta);                     % calculate te perpedicular velocity

G = 6.674*10^(-11);                 %Nm2.kg-1 - gravitational constant 
M = 4.8675*10^24;                   %kg - Mass of Venus
R = 6.0518e6;                       % radius R of Venus
H = 1.2e6;                          % define apoapsis altitude
m = 1500;                           %kg - Mass of spacecraft

v_orb = sqrt((G*M)/(R+H));          % calulate the require orbital velocity

Fb = 2*m*((v_orb-T-P)/magT);        % now calculate the burn force

Fb = Fb * unitvecT;                 % multiply by the unit vector to make force act in tangental direction 

end