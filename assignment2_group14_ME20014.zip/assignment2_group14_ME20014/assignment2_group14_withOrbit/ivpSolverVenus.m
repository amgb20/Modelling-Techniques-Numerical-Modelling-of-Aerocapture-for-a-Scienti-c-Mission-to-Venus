function [t, z] = ivpSolverVenus(t0,z0,dt,tend,count)
% ivpSolver    Solve an initial value problem (IVP) and plot the result
% 
%     [T,Z] = ivpSolver(T0,Z0,DT,TE) computes the IVP solution using a step 
%     size DT, beginning at time T0 and initial state Z0 and ending at time 
%     TEND. The solution is output as a time vector T and a matrix of state 
%     vectors Z.

% Here the input 'count' dictactes whether the burn will be applied at the
% apoapsis, when Initiate is called by shootingMethod, the count is set to
% 10 so that the burn force is never applied. When Initiate is called by
% outside of shootingMethod, count is set to 0 so that when the trajectory
% reaches the apoapsis, the force burn is applied. 

%% Initialise variables

t=zeros(1,20002);               % pre-allocation of vectors
z=zeros(4,20002); 

t(1) = t0;                      % initiate the t and z vecors first values to t0 and z0
z(:,1) = z0;

n=1;

%% determine next position

% loop for all time steps

while t(n) <= tend
    
    t(n+1) = t(n) + dt;         % increment time by 1 time step
    
    % calculate next z values
    [z(:,n+1),count] = stepRKVenus(z(:,n),dt, count);
    
    n = n+1;                    % increment n
  
end 

%% Plot the orbit path

figure(1)
plotcircle_function(0,0,6.0158*10^6,1000,'k');          
%plotting the planet using the plotcircle function from lectures

hold on
plotcircle_function(0,0,6.0158*10^6+190*10^3,1000,'r'); 
%plotting the atmoshpere - just for illustrative purposes

plot(z(1,:),z(2,:), 'b');           % plotting spacecraft trajectory
hold off

end

