function theta = calcTheta(z)
% this function calculates the angle between an incoming positional vector

theta = atan2(abs(z(2)),abs(z(1)));         % calculate theta

end
