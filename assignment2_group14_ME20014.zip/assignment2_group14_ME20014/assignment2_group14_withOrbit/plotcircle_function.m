function [x,y] = plotcircle_function(x0,y0,r,ntheta,colour)
%PLOTCIRCLE Generates ad plots a circle
%   [X, Y] = PLOTCIRCLE(X0,Y0,R,NTHETA,COLOUR] returns the X and Y
%   coordinates of a circle of radius R centred at the location (X0,Y0) for
%   NTHETA points along the circumference. Also plots circle in COLOUR.
%   Also plots circle with a sp

theta = [0:2*pi/(ntheta-1):2*pi];

x = r*cos(theta)+x0;
y = r*sin(theta)+y0;

plot(x,y,colour);
end

