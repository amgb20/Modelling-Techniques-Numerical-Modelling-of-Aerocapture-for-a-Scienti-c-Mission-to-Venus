function [dz,count] = stateDerivVenus(z,count)
% Calculate the state derivative for a spacecraft entering Venus'
% atmosphere.
% 
%     DZ = stateDeriv(T,Z) computes the derivative DZ = [V; A] of the 
%     state vector Z = [X; V], where X is displacement, V is velocity,
%     and A is acceleration.

%% Setting values of different parameters

R = 6.0518*10^6;                % Radius of Venus

%% Calculate the current Altitude 

alt = sqrt(z(1)^2+z(2)^2)-R;    % calculate the current altitude from current position and radius of Venus

%% Calculate forces

Fd = drag(z);                   % calculate the Drag Force
Fg = grav(z);                   % calculate the Gravital Force

%% Calculate next step output 

% if we are at the apoapsis, have passed the apo height on our entry to the planet and the count is 0... 
if alt<1200100 && alt>1199900 && z(2)<0 && count==0
    
    % if true, then add the burn force to the next step equation
    
    count = 1;              % set count to 1 to stop adding the burn for again
    [Fb] = burn(z);         %calculate the burn force
    
    dz1 = z(3:4);
    dz2 = Fg .* z(1:2) - Fd .* z(3:4) + Fb;      % calculate dz2 with the adition of the burn force.

else
    % otherwise calculate the dz using the normal equation
    dz1 = z(3:4);
    dz2 = Fg .* z(1:2) - Fd .* z(3:4);
    
end
    
    
dz = [dz1; dz2];            % create output vector comprising of dz1 and dz2


end

