function [T,unitvecT,magT] = calcT(z, theta)
% this function will calculate the Tangental velocity, it's unit vector and
% vector magnitude

%% Claculae the outputs

a=sin(theta);
b=cos(theta);
T = z(3)*a + z(4)*b;        % calculate the tangental velocity

Tx=T*sin(theta);            % calculate components values in x and y
Ty=T*cos(theta);
vecT=[Tx;Ty];               % create a vector of components

magT=sqrt(Tx^2+Ty^2);       % calculate the magnitude of the T vecotr
unitvecT=vecT/magT;         % calculate the unit vector

end
