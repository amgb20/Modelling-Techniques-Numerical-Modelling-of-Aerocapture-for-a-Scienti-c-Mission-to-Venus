function [apo,alt,z] = Initiate(alpha,count)
% Function holding the initial conditions for the IVPSOLVERVENUS.
% Call this function, inputting the value for ALPHA and start the COUNT at 0, to run the simulation.

%% Initialise paramters
t0 = 0;                         % initial time in seconds
z0 = [[10^7; 6.0518*10^6+alpha];
     [-11*10^3;0]];             % initial z in form [ [x0;y0] ; [x'0;y'0] ]
dt = 0.5;                       % time step in seconds
tend = 10000;                   % number of time steps in seconds


%% Launch simulation

[t,z] = ivpSolverVenus(t0,z0,dt,tend,count);      % call function IVP solver to simlate the full orbit


%% Plot variation of altitude

alt = sqrt(z(1,:).^2+z(2,:).^2)-6.0518*10^6;    % calculate the altitude for all z values. 
figure(2)
plot(t, alt, 'b');                              % plot graph of altiude against time
ylabel('Altitude (m)');                         % label axis
xlabel('Time (s)');


%% Calculate apoapsis 

% to find, look for the creast in the graph
for i=(2:(length(alt)-1))                       % loop through all altitude values, except the first and last
    if alt(i)>alt(i+1) && alt(i)>alt(i-1)       % if previous and next altitude values are lower...
        apo=alt(i);                             % if true, we are at the apoapsis, store value. 
    end
end

end

