function [znext,count] = stepRKVenus(z, dt, count)
% this function uses an aproximation method to accuratly determine the next
% step. 

%% Set the variables for the RK4 method

a = stateDerivVenus(z, count)*dt;                % determine next position
b = stateDerivVenus(z+a/2, count)*dt;
c = stateDerivVenus(z+b/2, count)*dt;
[d,count] = stateDerivVenus(z+c, count);       
% here count is recieved from StateDerivVenus to update value in IVP solver

d = d*dt; 

% Calculate the next state vector from the previous one using Runge-Kutta's
% equation
znext = z + 1/6 *(a+2*b+2*c+d);

