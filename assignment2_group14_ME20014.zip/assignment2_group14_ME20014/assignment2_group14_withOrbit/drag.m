function Fd = drag(z)
%Function computing the drag force acting on the spacecraft

%% Start by defining desnity as a function of altitude

R = 6.0518*10^6; % Radius of Venus in m

Alt = (sqrt(z(1)^2+z(2)^2)-R);          % current altitude of spacecraft

% if altitude is lower than 190e3 then we are in Venus' atmosphere
if Alt <= 190e3
    Rho = profileVenus(Alt);        % then use function to find current air density
else
    Rho = 0;                        % otherwise we are outside the atmospere, so no air density. 
end

%% Now compute Drag

A = 9;              % CS area of the spacecraft in m^2
Cd = 1.25;          % Drag coefficient
m = 1500;           % Mass of the spacecraft in Kg


Fd = ((Rho*A*Cd)/(2*m))*sqrt(z(3)^2+z(4)^2);        % calculate drag force

end

