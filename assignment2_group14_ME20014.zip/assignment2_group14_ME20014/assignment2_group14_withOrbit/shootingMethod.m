function [alpha, n] = shootingMethod(alpha1, alpha2)
% this function will take two extreme values of alpha and call the
% Initiate function to simulate the orbit and calculate the apoapsis by solving the BVP. 
% Then using an aporximation method, the function is re-called with changing vlaues of alpha
% to bring us closer to the apo target value without our error range.
% N will give the number of itterations it took to get a target apoapsis

%% Solving IVPs for initial guesses
 
Emax = 120;                     % maximum error 
apo_target = 1.2e6;             % target apoapsis desired
n = 1;                          % first iteration
count=10;

% Determine error of first guess
alpha(n) = alpha1;              % set first value of alpha vector to alpha1
apo(n) = Initiate(alpha(n),count);    % run simulation and calculate the apoapsis
E(n) = apo(n)-apo_target;       % calculate the error
n = n+1;                        % increase n

% Determine error of second guess
alpha(n) = alpha2;              % set second value of alpha vector to alpha2
apo(n) = Initiate(alpha(n),count);    % run simulation and calculate the apoapsis
E(n) = apo(n)-apo_target;       % calculate error
n = n+1;                        % increase n


%% Compute next guess until the error is low enough

% while our error is about the max allowed, iterate through the loop
while abs(E(n-1)) > Emax        
    
    % Determine a new educated guess for alpha
    alpha(n) = alpha(n-1)-E(n-1)*((alpha(n-1)-alpha(n-2))/(E(n-1)-E(n-2)));
    
    % Compute the apoapsis for the new value of alpha using same logic flow
    apo(n) = Initiate(alpha(n),count);
    E(n) = apo(n) - apo_target;
    n = n+1; 
end

%% Conclude 

alpha = alpha(length(alpha));       % final alpha value is our value with lowest error

end

