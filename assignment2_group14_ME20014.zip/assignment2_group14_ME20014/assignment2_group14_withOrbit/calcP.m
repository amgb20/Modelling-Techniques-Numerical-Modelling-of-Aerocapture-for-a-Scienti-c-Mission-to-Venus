function [P] = calcP(z,theta)
% This function will calculate the Perpendicular velocity

%% Calculate P

a=sin(theta);       % pre-assign values for easy computation
b=cos(theta);

P=((z(4)*(b^2 + 1))-z(3)*a*b)/a;    % calculate the Perpendicular velocity

end
