function [Fg] = grav(z)
%Function computing the value for the gravitational force.

G = 6.674*10^(-11);         % gravitational constant in Nm2.kg-1
M = 4.8675*10^24;           % Mass of Venus in Kg

Fg =  - (G*M)/((z(1)^2+z(2)^2)^(3/2));      % Calculate Gravitational Force 

end

