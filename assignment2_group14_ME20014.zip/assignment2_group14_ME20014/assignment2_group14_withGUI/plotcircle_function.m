function [x,y,w] = plotcircle_function(x0,y0,w0,x1,y1,nthata,color)
%PLOTCIRCLE Generates ad plots a circle
%   [X, Y] = PLOTCIRCLE(X0,Y0,Z0,R,NTHETA,COLOUR] returns the X, Y and Z
%   coordinates of a circle of radius R centred at the location (X0,Y0,Z0)
%   for NTHETA points along the circumference. Also plots circle in COLOUR.
%   Also plots circle with a sp

[x,y,w] = sphere;

r = 6.0158*10^6;
x = x*r + x0;
y = y*r + y0;
w = w*r + w0;

%theta = [0:2*pi/(ntheta-1):2*pi];

%r1 = r + 190e3;

%m = r1*cos(theta)+x1;
%n = r1*sin(theta)+y1;


%plot(m,n,color);

h = surfl(x,y,w);

set(h, 'FaceAlpha', 0.5);
shading interp;

title('shooting ');
ylabel('10^6 m');
xlabel('10^6 m');

end

