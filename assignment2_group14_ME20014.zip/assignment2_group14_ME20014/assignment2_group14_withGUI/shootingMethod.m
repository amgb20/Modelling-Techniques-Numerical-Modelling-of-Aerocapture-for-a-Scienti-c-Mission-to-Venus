function [alpha, n] = shootingMethod(alpha1, alpha2)
%SHOOT function applying the shooting method to reoslve a BVP. 
%   Two guesses for the initial value of alpha  ALPHA1 and ALPHA2 are the inputs.
%   These will then be the run as the inputs for the INITIATE function
%   which yields the APOAPSIS which is reached for the respective values of
%   ALPHA.
%   The error margin with the wanted value for the apoapsis APO_TARGET is then
%   determined. If that error margin is greater than an acceptable value
%   then iterate the previous process with another value for ALPHA for initial
%   position. 
%   Outputting N gives the number of iterations of alpha it took to
%   determine the first value with smallest error.

%% Solving IVPs for initial guesses
Emax = 1200; % maximum error 
apo_target = 1.2e6; % target apoapsis 
n = 1;

% Determine error of first guess
alpha(n) = alpha1;
apo(n) = Initiate(alpha(n));
E(n) = apo(n)-apo_target;
n = n+1;

% Determine error of second guess
alpha(n) = alpha2;
apo(n) = Initiate(alpha(n));
E(n) = apo(n)-apo_target;
n = n+1;


%% Compute next guess until the error is low enough

while abs(E(n-1)) > Emax
    
    % Determine a new educated guess for alpha
    alpha(n) = alpha(n-1)-E(n-1)*((alpha(n-1)-alpha(n-2))/(E(n-1)-E(n-2)));
    
    % Compute the resepctive apoapsis for the new value of alpha
    apo(n) = Initiate(alpha(n));
    E(n) = apo(n) - apo_target;
    n = n+1; % Increment n
end

%% Conclude 

% Assign the final value of alpha to the output variable
alpha = alpha(length(alpha));

end

