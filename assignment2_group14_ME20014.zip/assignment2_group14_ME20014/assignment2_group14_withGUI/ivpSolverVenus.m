function [t, z] = ivpSolverVenus(t0,z0,dt,tend)
% ivpSolver    Solve an initial value problem (IVP) and plot the result
% 
%     [T,Z] = ivpSolver(T0,Z0,DT,TE) computes the IVP solution using a step 
%     size DT, beginning at time T0 and initial state Z0 and ending at time 
%     TEND. The solution is output as a time vector T and a matrix of state 
%     vectors Z.


% Set initial conditions
t(1) = t0;
z(:,1) = z0;


% Continue stepping until the end time is exceeded
n=1;
while t(n) <= tend
    % Increment the time vector by one time step
    t(n+1) = t(n) + dt;
    
    % Apply RK method for one time step
    z(:,n+1) = stepRKVenus(t(n), z(:,n), dt); 
    
    
    n = n+1;
  
end 

%% Plots are muted
%Plot the result - plot the planet and the trajectory of the spacecraft
figure(1)
plotcircle_function(0,0,0,190e3,190e3,10000,'r'); %plotting the planet using the plotcircke function from lectures
hold on
plotcircle_function(190*10^3,190*10^3,190*10^3,'r'); %plotting the atmoshpere - just for illustrative purposes


plot(z(1,:),z(2,:), 'r:','LineWidth',3); % plotting spacecraft trajectory
hold off

end

