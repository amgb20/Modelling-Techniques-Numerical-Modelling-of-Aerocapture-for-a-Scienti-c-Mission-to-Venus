function Fd = drag(z)
%Function computing the drag force acting on the spacecraft

%% Start by defining desnity as a function of altitude

R = 6.0518*10^6; %m - Radius of Venus


Alt = (sqrt(z(1)^2+z(2)^2)-R); % Altitude of spacecraft

% Density of air in Venus' atmosphere 
if Alt <= 190e3
    Rho = profileVenus(Alt);
else
    Rho = 0;
end

%% Now computing for Drag

A = 9; %m2 - CS area of the spacecraft
Cd = 1.25; %Drag coefficient
m = 1500; %kg - Mass of the spacecraft


Fd = ((Rho*A*Cd)/(2*m))*sqrt(z(3)^2+z(4)^2);

end

