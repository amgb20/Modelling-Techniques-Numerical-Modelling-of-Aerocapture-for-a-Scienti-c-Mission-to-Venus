function [apo] = Initiate(alpha)
% Function holding the initial conditions for the IVPSOLVERVENUS.
% Call this function, inputting the value for ALPHA, to run the simulation.

%% Initialise paramters
t0 = 0; %s
z0 = [[10^7; 6.0518*10^6+alpha];[-11*10^3;0]]; % [ [x0;y0] ; [x'0;y'0] ]
dt = 0.5; %s
tend = 10000; %s


%% Launch simulation

[t,z] = ivpSolverVenus(t0,z0,dt,tend);


%% Plot variation of altitude
% Section to be muted in final iterations 

alt = sqrt(z(1,:).^2+z(2,:).^2)-6.0518*10^6;
% figure(2)
% plot(t, alt, 'b');
% ylabel('Altitude (m)');
% xlabel('Time (s)');
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%      Muting plot for now

%% Calculate apoapsis 

% apo = findpeaks(alt);

for i=(2:(length(alt)-1))
     if alt(i)>alt(i+1) && alt(i)>alt(i-1)
         apo = alt(i);
         disp(apo)
     end
 end

end

