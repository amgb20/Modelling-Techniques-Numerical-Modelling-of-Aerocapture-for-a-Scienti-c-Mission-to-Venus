function dz = stateDerivVenus(t, z)
% Calculate the state derivative for a spacecraft entering Venus'
% atmosphere.
% 
%     DZ = stateDeriv(T,Z) computes the derivative DZ = [V; A] of the 
%     state vector Z = [X; V], where X is displacement, V is velocity,
%     and A is acceleration.


%% Input function for forces
Fd = drag(z);
Fg = grav(z);

%% Complete the next two lines to calculate the state 

dz1 = z(3:4);
dz2 = Fg .* z(1:2) - Fd .* z(3:4);


dz = [dz1; dz2];
end

