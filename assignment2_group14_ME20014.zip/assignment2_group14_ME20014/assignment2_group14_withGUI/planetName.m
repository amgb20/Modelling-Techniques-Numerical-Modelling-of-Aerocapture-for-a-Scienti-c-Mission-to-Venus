function [name] = planetName(n)
%PLANETNAME Names of the planets
%   NAME = PLANETNAME(M) returns the name of the Nth planet from the sun.

if n == 1
    name = 'Mercury';
else 
    if n == 2
        name = 'Venus';
    else
        if n == 3
            name = 'Earth'
        else 
            if n == 4
                name = 'Mars'
            else 
                if n == 5
                    name = 'Jupiter'
                else
                    if n == 6
                        name = 'Saturn'
                    else 
                        if n == 7
                            name = 'Uranus'
                        else 
                            if n == 8
                                name = 'Neptune'
                            end 
                        end 
                    end
                end
            end
        end
    end
end                    
end
