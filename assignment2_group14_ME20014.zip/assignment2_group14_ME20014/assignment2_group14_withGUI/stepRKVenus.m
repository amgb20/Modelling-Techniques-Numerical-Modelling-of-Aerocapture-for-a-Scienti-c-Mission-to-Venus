function [znext] = stepRKVenus(t, z, dt)
%% Set the variables for the RK4 method

a = stateDerivVenus(t, z)*dt;
b = stateDerivVenus(t+dt/2, z+a/2)*dt;
c = stateDerivVenus(t+dt/2, z+b/2)*dt;
d = stateDerivVenus(t+dt, z+c)*dt;


% Calculate the next state vector from the previous one using Runge-Kutta's
% update equation
znext = z + 1/6 *(a+2*b+2*c+d);

