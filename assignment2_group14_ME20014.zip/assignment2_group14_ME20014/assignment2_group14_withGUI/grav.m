function [Fg] = grav(z)
%Function computing the value for the gravitational force.

G = 6.674*10^(-11); %Nm2.kg-1 - gravitational constant 
M = 4.8675*10^24; %kg - Mass of Venus

Fg =  - (G*M)/((z(1)^2+z(2)^2)^(3/2)); % Gravitational Force 
end

