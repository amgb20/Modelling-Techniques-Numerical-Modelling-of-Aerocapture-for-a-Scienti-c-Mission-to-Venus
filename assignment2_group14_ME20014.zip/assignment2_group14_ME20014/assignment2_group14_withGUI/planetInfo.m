function [mass,radius] = planetInfo(planet)
%PLANETINFO Distance and radius of the planet
%   [DISTANCE,RADIUS] = PLANETINFO(PLANET)returns the DISTANCE and
%   RADIUS in meters of PLANET

if ischar(planet)
    %input was string; convert to lower case
    name = lower(planet);
else 
    %input was number; convert to lower case string
    name = lower(planetName(planet));
end

if strcmp(name, 'mercury')
    mass = 0.33e24;
    radius = 2.440e6;

elseif strcmp(name, 'venus')
    mass = 4.87e24;
    radius = 6.052e6;
    
elseif strcmp(name, 'earth')
    mass = 5.97e24;
    radius = 6.371e6;
elseif strcmp(name, 'mars')
    mass = 0.642e24;
    radius = 3.39e6;
elseif strcmp(name, 'jupiter')
    mass = 1898e24;
    radius = 69.911e6;
elseif strcmp(name, 'saturn')
    mass = 568e24;
    radius = 58.232e6;
elseif strcmp(name, 'uranus')
    mass = 86.8e24;
    radius = 25.362e6;
elseif strcmp(name, 'neptune')
    mass = 102e24;
    radius = 24.622e6;
else 
    mass = Nan;
    radius = Nan;
end
